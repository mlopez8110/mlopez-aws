"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
require("source-map-support/register");
const DynamoAppointmentRepository_1 = require("../infrastructure/dynamo/DynamoAppointmentRepository");
const SnsPublisher_1 = require("../infrastructure/sns/SnsPublisher");
const AppointmentService_1 = require("../application/AppointmentService");
const tableName = process.env.APPOINTMENTS_TABLE || '';
const topicArn = process.env.SNS_TOPIC_ARN || '';
const repo = new DynamoAppointmentRepository_1.DynamoAppointmentRepository(tableName);
const sns = new SnsPublisher_1.SnsPublisher(topicArn);
const service = new AppointmentService_1.AppointmentService(repo, sns);
const handler = async (event) => {
    try {
        const method = event.httpMethod;
        console.log('Recepciob metodo:', method);
        if (method === 'POST') {
            const body = JSON.parse(event.body || '{}');
            console.log('Request body:', body);
            const appointment = await service.createAppointment(body);
            console.log('Cita creada:', appointment);
            return {
                statusCode: 200,
                body: JSON.stringify({ appointmentId: appointment.appointmentId, status: appointment.status })
            };
        }
        else if (method === 'GET') {
            const insuredId = event.pathParameters?.insuredId;
            if (!insuredId) {
                return { statusCode: 400, body: 'insuredId requerido' };
            }
            const items = await service.listByInsured(insuredId);
            return { statusCode: 200, body: JSON.stringify(items) };
        }
        else {
            return { statusCode: 405, body: 'Metodo no permitido' };
        }
    }
    catch (err) {
        console.error('Error en crear citas', err);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: err.message || 'Error' })
        };
    }
};
exports.handler = handler;
