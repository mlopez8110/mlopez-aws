"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const DynamoAppointmentRepository_1 = require("../infrastructure/dynamo/DynamoAppointmentRepository");
const tableName = process.env.APPOINTMENTS_TABLE || '';
const repo = new DynamoAppointmentRepository_1.DynamoAppointmentRepository(tableName);
function parseSqsRecord(record) {
    try {
        const body = JSON.parse(record.body || '{}');
        if (body.detail) {
            return body.detail;
        }
        return body;
    }
    catch (e) {
        return { raw: record.body };
    }
}
const handler = async (event) => {
    for (const record of event.Records) {
        try {
            const detail = parseSqsRecord(record);
            const appointmentId = detail.appointmentId;
            if (appointmentId) {
                await repo.updateStatus(appointmentId, 'completed');
            }
            else {
                console.warn('No se encontró ningún ID de cita a confirmar', detail);
            }
        }
        catch (err) {
            console.error('Error en handler de confirmacion', err);
        }
    }
    return {};
};
exports.handler = handler;
