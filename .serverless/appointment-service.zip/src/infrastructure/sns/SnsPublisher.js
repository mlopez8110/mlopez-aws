"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SnsPublisher = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
class SnsPublisher {
    constructor(topicArn) {
        //this.sns = new AWS.SNS({ region: process.env.AWS_REGION || 'us-east-1' });
        this.sns = new aws_sdk_1.default.SNS({ region: process.env.AWS_REGION });
        this.topicArn = topicArn;
    }
    async publish(message, countryISO) {
        const params = {
            TopicArn: this.topicArn,
            Message: JSON.stringify(message),
            MessageAttributes: {
                countryISO: {
                    DataType: 'String',
                    StringValue: countryISO
                }
            }
        };
        return this.sns.publish(params).promise();
    }
}
exports.SnsPublisher = SnsPublisher;
