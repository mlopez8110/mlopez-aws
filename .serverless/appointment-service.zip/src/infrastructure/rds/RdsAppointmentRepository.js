"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RdsAppointmentRepository = void 0;
const promise_1 = __importDefault(require("mysql2/promise"));
class RdsAppointmentRepository {
    constructor() {
        const host = process.env.RDS_HOST;
        const user = process.env.RDS_USER;
        const password = process.env.RDS_PASSWORD;
        const database = process.env.RDS_DATABASE;
        if (!host || !user || !database) {
            throw new Error('RDS credenciales no establecidas');
        }
        this.pool = promise_1.default.createPool({
            host, user, password, database, waitForConnections: true, connectionLimit: 5
        });
    }
    async saveToRDS(payload) {
        const { appointmentId, insuredId, scheduleId, countryISO, centerId = null, specialtyId = null, medicId = null, date = null, createdAt = new Date().toISOString() } = payload;
        const sql = `INSERT INTO rds_mysql (appointment_id, insuredId, scheduleId, centerId, specialtyId, medicId, date, countryISO, createdAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;
        const params = [appointmentId, insuredId, scheduleId, centerId, specialtyId, medicId, date, countryISO, createdAt];
        const conn = await this.pool.getConnection();
        try {
            await conn.execute(sql, params);
        }
        finally {
            conn.release();
        }
    }
}
exports.RdsAppointmentRepository = RdsAppointmentRepository;
