"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoAppointmentRepository = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
class DynamoAppointmentRepository {
    constructor(tableName) {
        this.client = new aws_sdk_1.default.DynamoDB.DocumentClient({ region: process.env.AWS_REGION });
        this.tableName = tableName;
    }
    async save(appointment) {
        await this.client.put({
            TableName: this.tableName,
            Item: appointment
        }).promise();
    }
    async findByInsuredId(insuredId) {
        const res = await this.client.query({
            TableName: this.tableName,
            IndexName: 'insuredId-index',
            KeyConditionExpression: 'insuredId = :i',
            ExpressionAttributeValues: {
                ':i': insuredId
            }
        }).promise();
        return (res.Items || []);
    }
    async updateStatus(appointmentId, status) {
        await this.client.update({
            TableName: this.tableName,
            Key: { appointmentId },
            UpdateExpression: 'SET #s = :s',
            ExpressionAttributeNames: { '#s': 'status' },
            ExpressionAttributeValues: { ':s': status }
        }).promise();
    }
}
exports.DynamoAppointmentRepository = DynamoAppointmentRepository;
