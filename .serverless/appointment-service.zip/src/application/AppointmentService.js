"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppointmentService = void 0;
const uuid_1 = require("uuid");
class AppointmentService {
    constructor(repo, publisher) {
        this.repo = repo;
        this.publisher = publisher;
    }
    async createAppointment(input) {
        console.log('Creando citas:', input);
        if (!input.insuredId || input.insuredId.length !== 5) {
            throw new Error('insuredId debe tener 5 caracteres');
        }
        if (!['PE', 'CL'].includes(input.countryISO)) {
            throw new Error('countryISO inválido. Sólo "PE" o "CL"');
        }
        const appointment = {
            appointmentId: (0, uuid_1.v4)(),
            insuredId: input.insuredId,
            scheduleId: input.scheduleId,
            countryISO: input.countryISO,
            status: 'pending',
            createdAt: new Date().toISOString(),
            centerId: input.centerId,
            specialtyId: input.specialtyId,
            medicId: input.medicId,
            date: input.date
        };
        await this.repo.save(appointment);
        console.log('Grabar cita en DynamoDB:', appointment);
        await this.publisher.publish(appointment, input.countryISO);
        console.log('Publicar cita en SNS:', appointment);
        return appointment;
    }
    async listByInsured(insuredId) {
        return this.repo.findByInsuredId(insuredId);
    }
}
exports.AppointmentService = AppointmentService;
